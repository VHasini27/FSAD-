## Packages
framer-motion | Smooth page transitions and complex animations
recharts | Visualizing career paths and statistics
date-fns | Formatting dates for timelines and notifications
lucide-react | Iconography (already in base, but ensuring availability)
clsx | Conditional class names utility
tailwind-merge | Utility for merging tailwind classes

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["var(--font-display)"],
  body: ["var(--font-body)"],
}
