export function Footer() {
  return (
    <footer className="border-t bg-slate-50 py-12 text-slate-600">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          <div className="col-span-1 md:col-span-2">
            <h3 className="font-display text-lg font-bold text-slate-900 mb-4">
              J&K Higher Education Advisor
            </h3>
            <p className="max-w-xs text-sm leading-relaxed">
              Empowering the youth of Jammu & Kashmir with personalized career guidance,
              college information, and educational resources.
            </p>
          </div>
          
          <div>
            <h4 className="font-semibold text-slate-900 mb-4">Resources</h4>
            <ul className="space-y-2 text-sm">
              <li><a href="#" className="hover:text-primary transition-colors">Career Guide</a></li>
              <li><a href="#" className="hover:text-primary transition-colors">Scholarships</a></li>
              <li><a href="#" className="hover:text-primary transition-colors">Exam Schedule</a></li>
              <li><a href="#" className="hover:text-primary transition-colors">Results Portal</a></li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-semibold text-slate-900 mb-4">Official Links</h4>
            <ul className="space-y-2 text-sm">
              <li><a href="#" className="hover:text-primary transition-colors">JK Higher Education Dept</a></li>
              <li><a href="#" className="hover:text-primary transition-colors">JK BOPEE</a></li>
              <li><a href="#" className="hover:text-primary transition-colors">University of Kashmir</a></li>
              <li><a href="#" className="hover:text-primary transition-colors">University of Jammu</a></li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-slate-200 pt-8 flex flex-col md:flex-row justify-between items-center text-sm">
          <p>© {new Date().getFullYear()} Government of Jammu & Kashmir. All rights reserved.</p>
          <div className="flex gap-4 mt-4 md:mt-0">
            <a href="#" className="hover:text-primary">Privacy Policy</a>
            <a href="#" className="hover:text-primary">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
