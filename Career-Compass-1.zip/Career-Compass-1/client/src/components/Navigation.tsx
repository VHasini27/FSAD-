import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { 
  GraduationCap, 
  Compass, 
  MapPin, 
  LayoutDashboard, 
  Bell, 
  LogOut,
  Menu,
  X
} from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { useNotifications } from "@/hooks/use-resources";

export function Navigation() {
  const [location] = useLocation();
  const { user, logout } = useAuth();
  const { data: notifications } = useNotifications();
  const [isOpen, setIsOpen] = useState(false);

  const unreadCount = notifications?.length || 0;

  const links = [
    { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
    { href: "/quiz", label: "Career Quiz", icon: Compass },
    { href: "/colleges", label: "Colleges", icon: MapPin },
    { href: "/career-map", label: "Career Paths", icon: GraduationCap },
  ];

  const isActive = (path: string) => location === path;

  return (
    <nav className="sticky top-0 z-50 w-full border-b bg-white/95 backdrop-blur supports-[backdrop-filter]:bg-white/60">
      <div className="container flex h-16 items-center px-4">
        {/* Logo */}
        <Link href="/" className="mr-6 flex items-center space-x-2">
          {/* Using a Lucide icon as placeholder logo, would normally be @assets/logo.png */}
          <div className="rounded-lg bg-primary p-1.5 text-primary-foreground">
            <GraduationCap className="h-6 w-6" />
          </div>
          <span className="hidden font-display text-xl font-bold sm:inline-block text-primary">
            J&K Education Advisor
          </span>
          <span className="font-display text-xl font-bold sm:hidden text-primary">
            J&K Edu
          </span>
        </Link>

        {/* Desktop Nav */}
        <div className="hidden md:flex md:flex-1 md:items-center md:space-x-4">
          {links.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className={`
                flex items-center space-x-2 text-sm font-medium transition-colors hover:text-primary
                ${isActive(link.href) ? "text-primary bg-primary/5 px-3 py-2 rounded-md" : "text-muted-foreground"}
              `}
            >
              <link.icon className="h-4 w-4" />
              <span>{link.label}</span>
            </Link>
          ))}
        </div>

        {/* Right Side Actions */}
        <div className="flex flex-1 items-center justify-end space-x-4">
          {user ? (
            <>
              {/* Notification Bell */}
              <div className="relative">
                <Button variant="ghost" size="icon" className="relative text-muted-foreground">
                  <Bell className="h-5 w-5" />
                  {unreadCount > 0 && (
                    <span className="absolute right-2 top-2 h-2 w-2 rounded-full bg-red-500 ring-2 ring-white" />
                  )}
                </Button>
              </div>

              {/* User Menu */}
              <div className="hidden md:flex items-center gap-4">
                <span className="text-sm font-medium text-slate-700">
                  {user.firstName || user.username}
                </span>
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={() => logout()}
                  className="gap-2 border-primary/20 hover:bg-primary/5 hover:text-primary"
                >
                  <LogOut className="h-4 w-4" />
                  Sign out
                </Button>
              </div>

              {/* Mobile Menu */}
              <Sheet open={isOpen} onOpenChange={setIsOpen}>
                <SheetTrigger asChild>
                  <Button variant="ghost" size="icon" className="md:hidden">
                    <Menu className="h-5 w-5" />
                  </Button>
                </SheetTrigger>
                <SheetContent side="right">
                  <div className="flex flex-col gap-6 pt-10">
                    {links.map((link) => (
                      <Link 
                        key={link.href} 
                        href={link.href}
                        onClick={() => setIsOpen(false)}
                        className={`
                          flex items-center gap-4 text-lg font-medium
                          ${isActive(link.href) ? "text-primary" : "text-muted-foreground"}
                        `}
                      >
                        <div className={`p-2 rounded-md ${isActive(link.href) ? "bg-primary/10" : "bg-slate-100"}`}>
                          <link.icon className="h-5 w-5" />
                        </div>
                        {link.label}
                      </Link>
                    ))}
                    <div className="h-px bg-border my-2" />
                    <Button 
                      variant="destructive" 
                      className="w-full justify-start gap-3"
                      onClick={() => logout()}
                    >
                      <LogOut className="h-4 w-4" />
                      Sign Out
                    </Button>
                  </div>
                </SheetContent>
              </Sheet>
            </>
          ) : (
            <Link href="/auth">
              <Button>Sign In</Button>
            </Link>
          )}
        </div>
      </div>
    </nav>
  );
}
