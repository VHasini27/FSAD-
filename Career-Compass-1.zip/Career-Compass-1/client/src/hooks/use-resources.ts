import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { api, type UpdateProfileRequest, type QuizSubmissionRequest, type CollegeFilters } from "@shared/routes";
import { z } from "zod";

// ============================================
// PROFILE & AUTH
// ============================================
export function useUser() {
  return useQuery({
    queryKey: [api.auth.me.path],
    queryFn: async () => {
      const res = await fetch(api.auth.me.path, { credentials: "include" });
      if (res.status === 401) return null;
      if (!res.ok) throw new Error("Failed to fetch user");
      return api.auth.me.responses[200].parse(await res.json());
    },
  });
}

export function useUpdateProfile() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: UpdateProfileRequest) => {
      const validated = api.profile.update.input.parse(data);
      const res = await fetch(api.profile.update.path, {
        method: api.profile.update.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validated),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to update profile");
      return api.profile.update.responses[200].parse(await res.json());
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: [api.auth.me.path] }),
  });
}

// ============================================
// QUIZ & RESULTS
// ============================================
export function useLatestQuiz() {
  return useQuery({
    queryKey: [api.quiz.latest.path],
    queryFn: async () => {
      const res = await fetch(api.quiz.latest.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch quiz results");
      return api.quiz.latest.responses[200].parse(await res.json());
    },
  });
}

export function useSubmitQuiz() {
  const queryClient = useQueryClient();
  return useMutation({
    mutationFn: async (data: QuizSubmissionRequest) => {
      const validated = api.quiz.submit.input.parse(data);
      const res = await fetch(api.quiz.submit.path, {
        method: api.quiz.submit.method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(validated),
        credentials: "include",
      });
      if (!res.ok) throw new Error("Failed to submit quiz");
      return api.quiz.submit.responses[201].parse(await res.json());
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [api.quiz.latest.path] });
      queryClient.invalidateQueries({ queryKey: [api.auth.me.path] }); // Re-fetch user in case dashboard needs updating
    },
  });
}

// ============================================
// COLLEGES
// ============================================
export function useColleges(filters?: CollegeFilters) {
  // Create a stable query key based on filters
  const queryKey = [api.colleges.list.path, filters];
  
  return useQuery({
    queryKey,
    queryFn: async () => {
      // Build URL with query params
      const url = new URL(api.colleges.list.path, window.location.origin);
      if (filters?.district) url.searchParams.append("district", filters.district);
      if (filters?.course) url.searchParams.append("course", filters.course);

      const res = await fetch(url.toString(), { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch colleges");
      return api.colleges.list.responses[200].parse(await res.json());
    },
  });
}

// ============================================
// NOTIFICATIONS
// ============================================
export function useNotifications() {
  return useQuery({
    queryKey: [api.notifications.list.path],
    queryFn: async () => {
      const res = await fetch(api.notifications.list.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch notifications");
      return api.notifications.list.responses[200].parse(await res.json());
    },
  });
}
