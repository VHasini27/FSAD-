import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { motion } from "framer-motion";
import { BookOpen, GraduationCap, Briefcase, TrendingUp } from "lucide-react";

const STREAMS = [
  {
    name: "Medical Science",
    color: "bg-green-100 text-green-800",
    icon: <TrendingUp className="h-5 w-5" />,
    paths: [
      { degree: "MBBS", careers: ["Doctor", "Surgeon", "Medical Researcher"] },
      { degree: "BDS", careers: ["Dentist", "Dental Surgeon"] },
      { degree: "B.Sc Nursing", careers: ["Nurse", "Health Administrator"] },
      { degree: "B.Pharma", careers: ["Pharmacist", "Drug Inspector"] },
    ]
  },
  {
    name: "Engineering (Non-Medical)",
    color: "bg-blue-100 text-blue-800",
    icon: <Briefcase className="h-5 w-5" />,
    paths: [
      { degree: "B.Tech/BE", careers: ["Software Engineer", "Civil Engineer", "Data Scientist"] },
      { degree: "B.Arch", careers: ["Architect", "Urban Planner"] },
      { degree: "B.Sc Physics/Maths", careers: ["Researcher", "Professor", "Statistician"] },
      { degree: "BCA", careers: ["Web Developer", "System Analyst"] },
    ]
  },
  {
    name: "Commerce & Management",
    color: "bg-purple-100 text-purple-800",
    icon: <TrendingUp className="h-5 w-5" />,
    paths: [
      { degree: "B.Com", careers: ["Accountant", "Banker", "Tax Consultant"] },
      { degree: "BBA", careers: ["HR Manager", "Marketing Executive", "Entrepreneur"] },
      { degree: "CA/CS", careers: ["Chartered Accountant", "Company Secretary"] },
      { degree: "B.Sc Economics", careers: ["Economist", "Financial Analyst"] },
    ]
  },
  {
    name: "Arts & Humanities",
    color: "bg-orange-100 text-orange-800",
    icon: <BookOpen className="h-5 w-5" />,
    paths: [
      { degree: "BA English/History", careers: ["Journalist", "Content Writer", "Civil Servant"] },
      { degree: "BA Psychology", careers: ["Psychologist", "Counselor", "HR Specialist"] },
      { degree: "BA Political Science", careers: ["Policy Analyst", "Public Relations", "NGO Worker"] },
      { degree: "Fine Arts", careers: ["Artist", "Graphic Designer", "Illustrator"] },
    ]
  }
];

export default function CareerMap() {
  return (
    <div className="min-h-screen bg-slate-50 pb-20">
      <div className="bg-primary text-primary-foreground py-12">
        <div className="container px-4">
          <h1 className="text-3xl font-display font-bold mb-4">Interactive Career Map</h1>
          <p className="text-blue-100 max-w-2xl">
            Visualize your future. See how different degrees lead to various career opportunities 
            in the government and private sectors.
          </p>
        </div>
      </div>

      <div className="container px-4 -mt-8">
        <div className="grid gap-8">
          {STREAMS.map((stream, idx) => (
            <motion.div
              key={stream.name}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.1 }}
            >
              <Card className="overflow-hidden border-0 shadow-lg shadow-slate-200/50">
                <CardHeader className="bg-white border-b border-slate-100 pb-4">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-xl flex items-center gap-3">
                      <div className={`p-2 rounded-lg ${stream.color}`}>
                        {stream.icon}
                      </div>
                      {stream.name}
                    </CardTitle>
                  </div>
                </CardHeader>
                <CardContent className="p-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                    {stream.paths.map((path, pIdx) => (
                      <div key={pIdx} className="relative group">
                        <div className="bg-slate-50 rounded-xl p-4 border border-slate-200 h-full hover:border-primary/50 hover:shadow-md transition-all">
                          <div className="flex items-center gap-2 mb-3 text-primary font-semibold">
                            <GraduationCap className="h-4 w-4" />
                            {path.degree}
                          </div>
                          
                          <div className="space-y-2">
                            {path.careers.map(career => (
                              <div key={career} className="flex items-center gap-2 text-sm text-slate-600">
                                <span className="h-1.5 w-1.5 rounded-full bg-slate-300 group-hover:bg-primary transition-colors" />
                                {career}
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}
