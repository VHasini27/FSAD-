import { useState } from "react";
import { useColleges } from "@/hooks/use-resources";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { MapPin, School, Search, GraduationCap } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

// Mock districts for filter
const DISTRICTS = [
  "Srinagar", "Jammu", "Anantnag", "Baramulla", "Budgam", 
  "Kathua", "Pulwama", "Kupwara", "Udhampur", "Doda"
];

export default function Colleges() {
  const [district, setDistrict] = useState<string>("");
  const [search, setSearch] = useState("");
  const { data: colleges, isLoading } = useColleges(district ? { district } : undefined);

  const filteredColleges = colleges?.filter(c => 
    c.name.toLowerCase().includes(search.toLowerCase()) || 
    c.courses.some(course => course.toLowerCase().includes(search.toLowerCase()))
  );

  return (
    <div className="min-h-screen bg-slate-50 pb-20">
      <div className="bg-slate-900 text-white py-12">
        <div className="container px-4 text-center">
          <h1 className="text-3xl font-display font-bold mb-4">Government College Directory</h1>
          <p className="text-slate-400 max-w-2xl mx-auto">
            Explore higher education institutions across Jammu & Kashmir. 
            Find detailed information about courses, eligibility, and facilities.
          </p>
        </div>
      </div>

      <div className="container px-4 -mt-8">
        {/* Filters Card */}
        <Card className="mb-8 shadow-lg border-0">
          <CardContent className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
                <Input 
                  placeholder="Search by college name or course..." 
                  className="pl-9"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                />
              </div>
              
              <Select value={district} onValueChange={setDistrict}>
                <SelectTrigger>
                  <SelectValue placeholder="Filter by District" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="ALL">All Districts</SelectItem>
                  {DISTRICTS.map(d => (
                    <SelectItem key={d} value={d}>{d}</SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Button variant="outline" onClick={() => { setDistrict(""); setSearch(""); }}>
                Reset Filters
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Results Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {isLoading ? (
            [1, 2, 3, 4, 5, 6].map((i) => (
              <Card key={i} className="overflow-hidden">
                <Skeleton className="h-40 w-full" />
                <CardContent className="p-6">
                  <Skeleton className="h-6 w-3/4 mb-2" />
                  <Skeleton className="h-4 w-1/2 mb-4" />
                  <Skeleton className="h-20 w-full" />
                </CardContent>
              </Card>
            ))
          ) : filteredColleges && filteredColleges.length > 0 ? (
            filteredColleges.map((college) => (
              <Card key={college.id} className="group hover:shadow-xl transition-shadow duration-300 overflow-hidden border-slate-200">
                <div className="h-32 bg-slate-100 relative">
                  {/* Fallback pattern for college image */}
                  <div className="absolute inset-0 bg-slate-200 flex items-center justify-center text-slate-400">
                    <School className="h-12 w-12" />
                  </div>
                  <div className="absolute top-4 right-4">
                    <Badge variant="secondary" className="bg-white/90 backdrop-blur text-slate-700">
                      {college.district}
                    </Badge>
                  </div>
                </div>
                
                <CardHeader>
                  <CardTitle className="text-lg leading-tight group-hover:text-primary transition-colors">
                    {college.name}
                  </CardTitle>
                  <CardDescription className="flex items-center gap-1">
                    <MapPin className="h-3 w-3" />
                    {college.location}
                  </CardDescription>
                </CardHeader>
                
                <CardContent className="space-y-4">
                  <div>
                    <h4 className="text-xs font-semibold uppercase text-muted-foreground mb-2">Popular Courses</h4>
                    <div className="flex flex-wrap gap-2">
                      {college.courses.slice(0, 3).map((course, idx) => (
                        <Badge key={idx} variant="outline" className="font-normal">
                          {course}
                        </Badge>
                      ))}
                      {college.courses.length > 3 && (
                        <Badge variant="outline" className="font-normal">+{college.courses.length - 3}</Badge>
                      )}
                    </div>
                  </div>

                  {college.eligibility && (
                    <div className="bg-blue-50 p-3 rounded-md text-xs text-blue-800">
                      <span className="font-semibold">Eligibility:</span> {college.eligibility}
                    </div>
                  )}

                  <Button className="w-full mt-2" variant="secondary">View Details</Button>
                </CardContent>
              </Card>
            ))
          ) : (
            <div className="col-span-full py-12 text-center text-muted-foreground">
              <School className="h-12 w-12 mx-auto mb-4 text-slate-300" />
              <p>No colleges found matching your criteria.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
