import { useAuth } from "@/hooks/use-auth";
import { useLatestQuiz, useNotifications, useUpdateProfile } from "@/hooks/use-resources";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { 
  ArrowRight, 
  BookOpen, 
  Briefcase, 
  MapPin, 
  User, 
  Calendar,
  AlertCircle
} from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { format } from "date-fns";
import { Badge } from "@/components/ui/badge";

export default function Dashboard() {
  const { user } = useAuth();
  const { data: quizResult, isLoading: isQuizLoading } = useLatestQuiz();
  const { data: notifications, isLoading: isNotifLoading } = useNotifications();

  // Greeting based on time of day
  const hour = new Date().getHours();
  const greeting = hour < 12 ? "Good morning" : hour < 18 ? "Good afternoon" : "Good evening";

  if (!user) return null;

  return (
    <div className="min-h-screen bg-slate-50 pb-20">
      {/* Hero Section */}
      <div className="bg-primary text-primary-foreground pb-20 pt-10">
        <div className="container px-4">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div>
              <h1 className="text-3xl md:text-4xl font-display font-bold mb-2">
                {greeting}, {user.firstName || user.username}!
              </h1>
              <p className="text-blue-100 max-w-xl">
                Ready to take the next step in your education journey? 
                Check your recommended paths below.
              </p>
            </div>
            
            {!quizResult && !isQuizLoading && (
              <Link href="/quiz">
                <Button variant="secondary" size="lg" className="shadow-lg shadow-black/10 font-semibold gap-2">
                  Take Aptitude Quiz
                  <ArrowRight className="h-4 w-4" />
                </Button>
              </Link>
            )}
          </div>
        </div>
      </div>

      <div className="container px-4 -mt-12 space-y-8">
        
        {/* Main Stats/Actions Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          
          {/* Aptitude Result Card */}
          <Card className="col-span-1 md:col-span-2 shadow-xl shadow-slate-200/50 border-0 overflow-hidden">
            <CardHeader className="bg-gradient-to-r from-blue-50 to-white border-b border-blue-100">
              <CardTitle className="flex items-center gap-2 text-primary">
                <Briefcase className="h-5 w-5" />
                Your Career Path
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-6">
              {isQuizLoading ? (
                <div className="space-y-3">
                  <Skeleton className="h-4 w-3/4" />
                  <Skeleton className="h-20 w-full" />
                </div>
              ) : quizResult ? (
                <div className="space-y-4">
                  <div>
                    <h3 className="text-sm font-medium text-muted-foreground uppercase tracking-wider mb-1">Recommended Stream</h3>
                    <p className="text-2xl font-bold text-slate-900">{quizResult.recommendedStream}</p>
                  </div>
                  
                  <div className="p-4 bg-slate-50 rounded-xl border border-slate-100">
                    <p className="text-sm text-slate-600 mb-4">
                      Based on your interests in {user.interests?.join(", ") || "various subjects"}, 
                      this stream aligns perfectly with your strengths.
                    </p>
                    <div className="flex gap-3">
                      <Link href="/colleges">
                        <Button size="sm" className="w-full sm:w-auto">Find Colleges</Button>
                      </Link>
                      <Link href="/career-map">
                        <Button size="sm" variant="outline" className="w-full sm:w-auto">View Career Map</Button>
                      </Link>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="text-center py-8">
                  <div className="mx-auto w-12 h-12 bg-blue-50 rounded-full flex items-center justify-center text-primary mb-3">
                    <BookOpen className="h-6 w-6" />
                  </div>
                  <h3 className="font-semibold text-slate-900 mb-1">Discover Your Potential</h3>
                  <p className="text-sm text-muted-foreground mb-4 max-w-sm mx-auto">
                    Take our 5-minute AI-powered assessment to get personalized stream and college recommendations.
                  </p>
                  <Link href="/quiz">
                    <Button>Start Assessment</Button>
                  </Link>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Quick Profile Card */}
          <Card className="shadow-lg shadow-slate-200/50 border-0">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-sm uppercase tracking-wider text-muted-foreground">
                <User className="h-4 w-4" />
                Student Profile
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex justify-between items-center py-2 border-b border-slate-100">
                  <span className="text-sm text-slate-500">Class Level</span>
                  <span className="font-medium">{user.classLevel ? `Class ${user.classLevel}` : "Not Set"}</span>
                </div>
                <div className="flex justify-between items-center py-2 border-b border-slate-100">
                  <span className="text-sm text-slate-500">Location</span>
                  <span className="font-medium">{user.location || "J&K"}</span>
                </div>
                <div className="flex justify-between items-center py-2 border-b border-slate-100">
                  <span className="text-sm text-slate-500">Academic Score</span>
                  <span className="font-medium">{user.academicPerformance || "-"}</span>
                </div>
                <Button variant="outline" className="w-full mt-2" size="sm">
                  Edit Profile
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Notifications & Timeline */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <h2 className="text-xl font-display font-bold text-slate-900 mb-4">Important Updates</h2>
            <div className="space-y-4">
              {isNotifLoading ? (
                [1, 2, 3].map((i) => <Skeleton key={i} className="h-24 w-full rounded-xl" />)
              ) : notifications && notifications.length > 0 ? (
                notifications.map((notif) => (
                  <div 
                    key={notif.id} 
                    className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm hover:shadow-md transition-shadow flex gap-4"
                  >
                    <div className={`
                      flex-shrink-0 w-12 h-12 rounded-full flex items-center justify-center
                      ${notif.type === 'admission' ? 'bg-green-100 text-green-600' : 
                        notif.type === 'exam' ? 'bg-red-100 text-red-600' : 'bg-blue-100 text-blue-600'}
                    `}>
                      <Calendar className="h-5 w-5" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <h4 className="font-semibold text-slate-900">{notif.title}</h4>
                        <Badge variant="outline" className="text-xs uppercase bg-slate-50">{notif.type}</Badge>
                      </div>
                      <p className="text-sm text-slate-600 mb-2">{notif.content}</p>
                      <p className="text-xs text-muted-foreground">
                        {format(new Date(notif.date), "PPP")}
                      </p>
                    </div>
                  </div>
                ))
              ) : (
                <div className="bg-white p-8 rounded-xl border border-dashed border-slate-300 text-center">
                  <p className="text-muted-foreground">No new notifications at this time.</p>
                </div>
              )}
            </div>
          </div>

          <div>
            <h2 className="text-xl font-display font-bold text-slate-900 mb-4">Nearby Colleges</h2>
            <Card className="bg-slate-900 text-white overflow-hidden relative">
              {/* Abstract map background pattern */}
              <div className="absolute inset-0 opacity-10 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-white via-slate-900 to-slate-900"></div>
              
              <CardContent className="relative z-10 p-6 flex flex-col items-center text-center space-y-4">
                <MapPin className="h-10 w-10 text-accent" />
                <div>
                  <h3 className="font-bold text-lg mb-1">Find Colleges Near You</h3>
                  <p className="text-slate-400 text-sm">
                    Explore government colleges in your district with detailed course info.
                  </p>
                </div>
                <Link href="/colleges">
                  <Button className="w-full bg-accent text-accent-foreground hover:bg-accent/90">
                    Explore Directory
                  </Button>
                </Link>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
