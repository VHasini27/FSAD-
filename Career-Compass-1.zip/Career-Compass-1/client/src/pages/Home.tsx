import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/use-auth";
import { Redirect } from "wouter";
import { ArrowRight, CheckCircle2, Map, ShieldCheck, GraduationCap } from "lucide-react";

export default function Home() {
  const { user, isLoading } = useAuth();

  if (!isLoading && user) {
    return <Redirect to="/dashboard" />;
  }

  return (
    <div className="min-h-screen bg-white">
      {/* Navbar Placeholder - typically handled by layout but added for Landing page structure */}
      <nav className="border-b py-4 px-6 flex justify-between items-center bg-white/80 backdrop-blur sticky top-0 z-50">
        <div className="flex items-center gap-2 font-bold text-primary text-xl">
          <GraduationCap className="h-6 w-6" />
          <span>J&K Education Advisor</span>
        </div>
        <Link href="/auth">
          <Button>Sign In / Register</Button>
        </Link>
      </nav>

      {/* Hero Section */}
      <section className="relative overflow-hidden pt-16 pb-32 lg:pt-32">
        <div className="container mx-auto px-4 text-center">
          <div className="inline-flex items-center rounded-full border px-3 py-1 text-sm text-muted-foreground mb-6 bg-slate-50">
            <span className="flex h-2 w-2 rounded-full bg-primary mr-2"></span>
            Official J&K Government Initiative
          </div>
          
          <h1 className="text-4xl md:text-6xl font-display font-bold text-slate-900 tracking-tight mb-6 max-w-4xl mx-auto">
            Your Future Starts Here. <br />
            <span className="text-primary">Personalized Career Guidance</span>
          </h1>
          
          <p className="text-lg md:text-xl text-slate-600 max-w-2xl mx-auto mb-10">
            Helping students of Class 10th and 12th discover their strengths, 
            choose the right stream, and find the best colleges in Jammu & Kashmir.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/auth">
              <Button size="lg" className="h-12 px-8 text-base">
                Get Started
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
            <Button size="lg" variant="outline" className="h-12 px-8 text-base">
              Learn More
            </Button>
          </div>
        </div>
        
        {/* Abstract shapes/decoration */}
        <div className="absolute top-1/2 left-0 -translate-y-1/2 w-64 h-64 bg-blue-50 rounded-full blur-3xl opacity-50 -z-10" />
        <div className="absolute top-0 right-0 w-96 h-96 bg-indigo-50 rounded-full blur-3xl opacity-50 -z-10" />
      </section>

      {/* Features Section */}
      <section className="py-24 bg-slate-50">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                icon: <ShieldCheck className="h-8 w-8 text-primary" />,
                title: "AI Aptitude Assessment",
                description: "Discover your strengths with our scientifically designed quiz that maps your personality to ideal career paths."
              },
              {
                icon: <Map className="h-8 w-8 text-primary" />,
                title: "College Directory",
                description: "Find government colleges near you with detailed information on courses, eligibility, and facilities."
              },
              {
                icon: <GraduationCap className="h-8 w-8 text-primary" />,
                title: "Career Mapping",
                description: "Visualize your journey from degree to career with interactive charts showing clear pathways."
              }
            ].map((feature, i) => (
              <div key={i} className="bg-white p-8 rounded-2xl border border-slate-100 shadow-lg shadow-slate-200/50 hover:-translate-y-1 transition-transform duration-300">
                <div className="mb-4 bg-blue-50 w-16 h-16 rounded-xl flex items-center justify-center">
                  {feature.icon}
                </div>
                <h3 className="text-xl font-bold mb-2 font-display">{feature.title}</h3>
                <p className="text-slate-600 leading-relaxed">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Trust Section */}
      <section className="py-20 border-t">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold font-display mb-12">Why Choose Us?</h2>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              "Government Verified Data",
              "Local Context Focus",
              "Free for All Students",
              "Secure & Private"
            ].map((item, i) => (
              <div key={i} className="flex flex-col items-center gap-3">
                <CheckCircle2 className="h-8 w-8 text-green-500" />
                <span className="font-semibold text-lg">{item}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-slate-900 text-white py-12">
        <div className="container mx-auto px-4 text-center">
          <div className="flex items-center justify-center gap-2 mb-6">
            <GraduationCap className="h-8 w-8" />
            <span className="text-2xl font-bold font-display">J&K Education Advisor</span>
          </div>
          <p className="text-slate-400 mb-8 max-w-md mx-auto">
            Empowering the youth of Jammu & Kashmir with the right guidance for a brighter future.
          </p>
          <div className="text-sm text-slate-500">
            © {new Date().getFullYear()} Government of Jammu & Kashmir. All rights reserved.
          </div>
        </div>
      </footer>
    </div>
  );
}
