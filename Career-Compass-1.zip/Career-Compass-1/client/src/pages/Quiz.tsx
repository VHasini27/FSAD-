import { useState } from "react";
import { useSubmitQuiz } from "@/hooks/use-resources";
import { Redirect } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Card, CardContent } from "@/components/ui/card";
import { ArrowLeft, ArrowRight, Check, Loader2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { type InsertQuizResultSchema } from "@shared/schema";

// Simple logical steps for the quiz
const STEPS = [
  {
    id: "interests",
    title: "What subjects interest you most?",
    description: "Select up to 3 subjects you enjoy studying.",
    options: [
      "Mathematics", "Physics", "Chemistry", "Biology", 
      "History", "Political Science", "Economics", "Business Studies",
      "Computer Science", "Art & Design", "Literature"
    ],
    multi: true,
    max: 3
  },
  {
    id: "skills",
    title: "What are your strongest skills?",
    description: "Choose the skills that come naturally to you.",
    options: [
      "Problem Solving", "Creative Thinking", "Memorization",
      "Communication", "Logical Reasoning", "Hands-on Work",
      "Analyzing Data", "Helping Others"
    ],
    multi: true,
    max: 3
  },
  {
    id: "work_style",
    title: "How do you prefer to work?",
    description: "Pick the environment you thrive in.",
    options: [
      "Independently in a quiet space",
      "Collaborating with a team",
      "Outdoors or in the field",
      "In a structured office/lab environment"
    ],
    multi: false
  },
  {
    id: "goals",
    title: "What is your primary career goal?",
    description: "This helps us align your long-term vision.",
    options: [
      "High Earning Potential",
      "Social Impact / Helping Society",
      "Innovation & Creativity",
      "Stability & Work-Life Balance",
      "Research & Discovery"
    ],
    multi: false
  }
];

export default function Quiz() {
  const [currentStep, setCurrentStep] = useState(0);
  const [answers, setAnswers] = useState<Record<string, any>>({});
  const { mutate: submitQuiz, isPending, isSuccess } = useSubmitQuiz();
  const { toast } = useToast();

  const step = STEPS[currentStep];
  const progress = ((currentStep + 1) / STEPS.length) * 100;

  const handleSelect = (option: string) => {
    const current = answers[step.id] || [];
    
    if (step.multi) {
      if (current.includes(option)) {
        setAnswers({ ...answers, [step.id]: current.filter((o: string) => o !== option) });
      } else if (current.length < (step.max || 10)) {
        setAnswers({ ...answers, [step.id]: [...current, option] });
      }
    } else {
      setAnswers({ ...answers, [step.id]: [option] });
      // Auto advance for single select after short delay
      setTimeout(handleNext, 300);
    }
  };

  const handleNext = () => {
    if (currentStep < STEPS.length - 1) {
      setCurrentStep(prev => prev + 1);
    } else {
      handleSubmit();
    }
  };

  const handleBack = () => {
    if (currentStep > 0) {
      setCurrentStep(prev => prev - 1);
    }
  };

  const handleSubmit = () => {
    // Basic logic to determine stream based on answers (mock logic)
    // Real app would have complex logic or call AI endpoint
    let recommendedStream = "General";
    const interests = answers["interests"] || [];
    
    if (interests.some((i: string) => ["Physics", "Mathematics", "Computer Science"].includes(i))) {
      recommendedStream = "Engineering (Non-Medical)";
    } else if (interests.some((i: string) => ["Biology", "Chemistry"].includes(i))) {
      recommendedStream = "Medical Science";
    } else if (interests.some((i: string) => ["Business Studies", "Economics"].includes(i))) {
      recommendedStream = "Commerce & Management";
    } else if (interests.some((i: string) => ["History", "Literature", "Political Science"].includes(i))) {
      recommendedStream = "Arts & Humanities";
    }

    submitQuiz({
      answers,
      recommendedStream
    });
  };

  if (isSuccess) {
    return <Redirect to="/dashboard" />;
  }

  const isStepValid = (answers[step.id]?.length || 0) > 0;

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-4">
      <div className="w-full max-w-2xl">
        {/* Header */}
        <div className="mb-8 text-center">
          <h1 className="text-2xl font-bold font-display text-slate-900 mb-2">Career Aptitude Assessment</h1>
          <p className="text-muted-foreground">Step {currentStep + 1} of {STEPS.length}</p>
        </div>

        {/* Progress Bar */}
        <div className="mb-8">
          <Progress value={progress} className="h-2" />
        </div>

        {/* Question Card */}
        <Card className="border-0 shadow-xl shadow-slate-200/50 overflow-hidden">
          <CardContent className="p-8">
            <AnimatePresence mode="wait">
              <motion.div
                key={step.id}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.2 }}
                className="space-y-6"
              >
                <div>
                  <h2 className="text-2xl font-bold text-slate-900 mb-2">{step.title}</h2>
                  <p className="text-slate-500">{step.description}</p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {step.options.map((option) => {
                    const isSelected = (answers[step.id] || []).includes(option);
                    return (
                      <button
                        key={option}
                        onClick={() => handleSelect(option)}
                        className={`
                          p-4 rounded-xl text-left transition-all duration-200 border-2
                          flex items-center justify-between group
                          ${isSelected 
                            ? "border-primary bg-primary/5 text-primary shadow-inner" 
                            : "border-slate-100 bg-white hover:border-primary/30 hover:shadow-md text-slate-700"
                          }
                        `}
                      >
                        <span className="font-medium">{option}</span>
                        {isSelected && (
                          <div className="h-5 w-5 bg-primary rounded-full flex items-center justify-center text-white">
                            <Check className="h-3 w-3" />
                          </div>
                        )}
                      </button>
                    );
                  })}
                </div>
              </motion.div>
            </AnimatePresence>

            {/* Actions */}
            <div className="flex justify-between mt-8 pt-8 border-t border-slate-100">
              <Button 
                variant="ghost" 
                onClick={handleBack} 
                disabled={currentStep === 0 || isPending}
                className="text-slate-500"
              >
                <ArrowLeft className="mr-2 h-4 w-4" />
                Back
              </Button>

              <Button 
                onClick={handleNext} 
                disabled={!isStepValid || isPending}
                className="px-8"
              >
                {isPending ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Analyzing...
                  </>
                ) : currentStep === STEPS.length - 1 ? (
                  "Complete Assessment"
                ) : (
                  <>
                    Next Step
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </>
                )}
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
