import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { setupAuth, registerAuthRoutes } from "./replit_integrations/auth";
import { z } from "zod";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Setup Replit Auth
  await setupAuth(app);
  registerAuthRoutes(app);

  // Helper to get local app user from Replit user
  const getAppUser = async (req: any) => {
    if (!req.isAuthenticated()) return null;
    const replitId = req.user.claims.sub;
    let user = await storage.getUserByReplitId(replitId);
    if (!user) {
      user = await storage.createUser({
        replitId,
        username: req.user.claims.email || `user_${replitId.substring(0, 8)}`,
        interests: [],
      });
    }
    return user;
  };

  app.get(api.auth.me.path, async (req, res) => {
    const user = await getAppUser(req);
    res.json(user);
  });

  app.patch(api.profile.update.path, async (req, res) => {
    const user = await getAppUser(req);
    if (!user) return res.status(401).json({ message: "Unauthorized" });

    try {
      const updates = api.profile.update.input.parse(req.body);
      const updatedUser = await storage.updateUser(user.id, updates);
      res.json(updatedUser);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      res.status(500).json({ message: "Internal Server Error" });
    }
  });

  app.post(api.quiz.submit.path, async (req, res) => {
    const user = await getAppUser(req);
    if (!user) return res.status(401).json({ message: "Unauthorized" });

    try {
      const submission = api.quiz.submit.input.parse(req.body);
      const result = await storage.submitQuiz(user.id, submission);
      res.status(201).json(result);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      res.status(500).json({ message: "Internal Server Error" });
    }
  });

  app.get(api.quiz.latest.path, async (req, res) => {
    const user = await getAppUser(req);
    if (!user) return res.json(null);
    const result = await storage.getLatestQuiz(user.id);
    res.json(result || null);
  });

  app.get(api.colleges.list.path, async (req, res) => {
    const filters = req.query as any;
    const colleges = await storage.getColleges(filters);
    res.json(colleges);
  });

  app.get(api.notifications.list.path, async (req, res) => {
    const user = await getAppUser(req);
    const notes = await storage.getNotifications(user?.id);
    res.json(notes);
  });

  // Seed Data
  async function seedDatabase() {
    const existingColleges = await storage.getColleges();
    if (existingColleges.length === 0) {
      await storage.getColleges(); // Just a check
      const seedColleges = [
        { name: "Government Degree College, Jammu", location: "Jammu", district: "Jammu", courses: ["Arts", "Science", "Commerce"], eligibility: "Class 12 Pass", facilities: ["Library", "Labs"] },
        { name: "S.P. College, Srinagar", location: "Srinagar", district: "Srinagar", courses: ["Science", "Vocational"], eligibility: "Class 12 Pass", facilities: ["Library", "Auditorium"] },
        { name: "GDC Kathua", location: "Kathua", district: "Kathua", courses: ["Commerce", "Arts"], eligibility: "Class 12 Pass", facilities: ["Sports Ground"] }
      ];
      for (const c of seedColleges) {
        // Simple insert for seed
        await storage.createUser({ replitId: "system", username: "system", interests: [] }); // Dummy for storage check if needed
        // Assuming storage handles it or use db directly for seeds
      }
    }
  }
  // seedDatabase(); // Call or export

  return httpServer;
}
