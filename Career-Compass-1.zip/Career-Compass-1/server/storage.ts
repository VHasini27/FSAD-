import { db } from "./db";
import {
  users,
  quizResults,
  colleges,
  notifications,
  type User,
  type InsertUser,
  type QuizResult,
  type QuizSubmissionRequest,
  type College,
  type AppNotification,
  type UpdateProfileRequest
} from "@shared/schema";
import { eq, and, desc } from "drizzle-orm";

export interface IStorage {
  // User operations
  getUserByReplitId(replitId: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, updates: UpdateProfileRequest): Promise<User>;

  // Quiz operations
  submitQuiz(userId: number, submission: QuizSubmissionRequest): Promise<QuizResult>;
  getLatestQuiz(userId: number): Promise<QuizResult | undefined>;

  // College operations
  getColleges(filters?: { district?: string; course?: string }): Promise<College[]>;

  // Notification operations
  getNotifications(userId?: number): Promise<AppNotification[]>;
}

export class DatabaseStorage implements IStorage {
  async getUserByReplitId(replitId: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.replitId, replitId));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async updateUser(id: number, updates: UpdateProfileRequest): Promise<User> {
    const [user] = await db.update(users).set(updates).where(eq(users.id, id)).returning();
    return user;
  }

  async submitQuiz(userId: number, submission: QuizSubmissionRequest): Promise<QuizResult> {
    const [result] = await db.insert(quizResults).values({ ...submission, userId }).returning();
    return result;
  }

  async getLatestQuiz(userId: number): Promise<QuizResult | undefined> {
    const [result] = await db.select().from(quizResults).where(eq(quizResults.userId, userId)).orderBy(desc(quizResults.createdAt)).limit(1);
    return result;
  }

  async getColleges(filters?: { district?: string; course?: string }): Promise<College[]> {
    let query = db.select().from(colleges);
    if (filters?.district || filters?.course) {
      // Simple filtering logic
      const results = await query;
      return results.filter(c => {
        const districtMatch = !filters.district || c.district.toLowerCase() === filters.district.toLowerCase();
        const courseMatch = !filters.course || c.courses.some(course => course.toLowerCase().includes(filters.course!.toLowerCase()));
        return districtMatch && courseMatch;
      });
    }
    return await query;
  }

  async getNotifications(userId?: number): Promise<AppNotification[]> {
    if (userId) {
      return await db.select().from(notifications).where(and(eq(notifications.isGlobal, true), eq(notifications.userId, userId)));
    }
    return await db.select().from(notifications).where(eq(notifications.isGlobal, true));
  }
}

export const storage = new DatabaseStorage();
