import { z } from "zod";
import { insertUserSchema, insertQuizResultSchema, users, quizResults, colleges, notifications } from "./schema";

export const errorSchemas = {
  validation: z.object({ message: z.string(), field: z.string().optional() }),
  notFound: z.object({ message: z.string() }),
  unauthorized: z.object({ message: z.string() }),
};

export const api = {
  auth: {
    me: {
      method: "GET" as const,
      path: "/api/me",
      responses: {
        200: z.custom<typeof users.$inferSelect>().nullable(),
      },
    },
  },
  profile: {
    update: {
      method: "PATCH" as const,
      path: "/api/profile",
      input: insertUserSchema.partial().omit({ replitId: true, username: true }),
      responses: {
        200: z.custom<typeof users.$inferSelect>(),
        401: errorSchemas.unauthorized,
      },
    },
  },
  quiz: {
    submit: {
      method: "POST" as const,
      path: "/api/quiz/submit",
      input: insertQuizResultSchema.omit({ userId: true }),
      responses: {
        201: z.custom<typeof quizResults.$inferSelect>(),
        401: errorSchemas.unauthorized,
      },
    },
    latest: {
      method: "GET" as const,
      path: "/api/quiz/latest",
      responses: {
        200: z.custom<typeof quizResults.$inferSelect>().nullable(),
      },
    },
  },
  colleges: {
    list: {
      method: "GET" as const,
      path: "/api/colleges",
      input: z.object({
        district: z.string().optional(),
        course: z.string().optional(),
      }).optional(),
      responses: {
        200: z.array(z.custom<typeof colleges.$inferSelect>()),
      },
    },
  },
  notifications: {
    list: {
      method: "GET" as const,
      path: "/api/notifications",
      responses: {
        200: z.array(z.custom<typeof notifications.$inferSelect>()),
      },
    },
  },
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
