import { pgTable, text, serial, integer, varchar, timestamp, boolean, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User profiles (extending Replit Auth)
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  replitId: text("replit_id").notNull().unique(),
  username: text("username").notNull(),
  age: integer("age"),
  gender: text("gender"),
  classLevel: text("class_level"), // "10" or "12"
  interests: text("interests").array(),
  academicPerformance: text("academic_performance"),
  location: text("location"),
});

// Quiz results and recommendations
export const quizResults = pgTable("quiz_results", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  answers: jsonb("answers").notNull(),
  recommendedStream: text("recommended_stream").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

// College directory
export const colleges = pgTable("colleges", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  location: text("location").notNull(),
  district: text("district").notNull(),
  courses: text("courses").array().notNull(),
  eligibility: text("eligibility").notNull(),
  facilities: text("facilities").array(),
  cutoff: text("cutoff"),
});

// Notifications and Timelines
export const notifications = pgTable("notifications", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  content: text("content").notNull(),
  type: text("type").notNull(), // "admission", "scholarship", "exam"
  date: timestamp("date").notNull(),
  isGlobal: boolean("is_global").default(true),
  userId: integer("user_id").references(() => users.id),
});

// Base Schemas
export const insertUserSchema = createInsertSchema(users).omit({ id: true });
export const insertQuizResultSchema = createInsertSchema(quizResults).omit({ id: true, createdAt: true });
export const insertCollegeSchema = createInsertSchema(colleges).omit({ id: true });
export const insertNotificationSchema = createInsertSchema(notifications).omit({ id: true });

// Explicit API Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type QuizResult = typeof quizResults.$inferSelect;
export type College = typeof colleges.$inferSelect;
export type AppNotification = typeof notifications.$inferSelect;

export type UpdateProfileRequest = Partial<Omit<InsertUser, "replitId" | "username">>;
export type QuizSubmissionRequest = z.infer<typeof insertQuizResultSchema>;
export type CollegeFilters = {
  district?: string;
  course?: string;
};
